package com.patientapp.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class UserInfoSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer userInfoId ;
		private $$JAVA_FIELD_TYPE$$ userFirstName $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ userLastName $$HASH_SET$$;
	private Organisations organisationsUserOrg $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ loginId $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ loginEmailId $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ contactNo $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ loginPassword $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ resetToken $$HASH_SET$$;

	public UserInfoSearch()
	{
	}
	public java.lang.Integer getUserInfoSearchId()
	{
		return this.userInfoId;
	}
	public void setUserInfoSearchId(java.lang.Integer messageQueueId)
	{
		this.userInfoId = userInfoId;
	}
		public $$JAVA_FIELD_TYPE$$ getUserFirstName()
	{
		return this.userFirstName;
	}
	public void setUserFirstName($$JAVA_FIELD_TYPE$$ userFirstName)
	{
		this.userFirstName = userFirstName;
	}
	public $$JAVA_FIELD_TYPE$$ getUserLastName()
	{
		return this.userLastName;
	}
	public void setUserLastName($$JAVA_FIELD_TYPE$$ userLastName)
	{
		this.userLastName = userLastName;
	}
	public Organisations getOrganisationsUserOrg()
	{
		return this.organisationsUserOrg;
	}
	public void setOrganisationsUserOrg(Organisations organisationsUserOrg)
	{
		this.organisationsUserOrg = organisationsUserOrg;
	}
	public $$JAVA_FIELD_TYPE$$ getLoginId()
	{
		return this.loginId;
	}
	public void setLoginId($$JAVA_FIELD_TYPE$$ loginId)
	{
		this.loginId = loginId;
	}
	public $$JAVA_FIELD_TYPE$$ getLoginEmailId()
	{
		return this.loginEmailId;
	}
	public void setLoginEmailId($$JAVA_FIELD_TYPE$$ loginEmailId)
	{
		this.loginEmailId = loginEmailId;
	}
	public $$JAVA_FIELD_TYPE$$ getContactNo()
	{
		return this.contactNo;
	}
	public void setContactNo($$JAVA_FIELD_TYPE$$ contactNo)
	{
		this.contactNo = contactNo;
	}
	public $$JAVA_FIELD_TYPE$$ getLoginPassword()
	{
		return this.loginPassword;
	}
	public void setLoginPassword($$JAVA_FIELD_TYPE$$ loginPassword)
	{
		this.loginPassword = loginPassword;
	}
	public $$JAVA_FIELD_TYPE$$ getResetToken()
	{
		return this.resetToken;
	}
	public void setResetToken($$JAVA_FIELD_TYPE$$ resetToken)
	{
		this.resetToken = resetToken;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
