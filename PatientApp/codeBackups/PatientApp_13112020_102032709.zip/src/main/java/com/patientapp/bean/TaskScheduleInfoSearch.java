package com.patientapp.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class TaskScheduleInfoSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer taskScheduleInfoId ;
		private TaskInfo taskInfo $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ targetEntityId $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ targetUserId $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ notificationMedium $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ notificationLastSentTime $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ nextNotificationTime $$HASH_SET$$;

	public TaskScheduleInfoSearch()
	{
	}
	public java.lang.Integer getTaskScheduleInfoSearchId()
	{
		return this.taskScheduleInfoId;
	}
	public void setTaskScheduleInfoSearchId(java.lang.Integer messageQueueId)
	{
		this.taskScheduleInfoId = taskScheduleInfoId;
	}
		public TaskInfo getTaskInfo()
	{
		return this.taskInfo;
	}
	public void setTaskInfo(TaskInfo taskInfo)
	{
		this.taskInfo = taskInfo;
	}
	public $$JAVA_FIELD_TYPE$$ getTargetEntityId()
	{
		return this.targetEntityId;
	}
	public void setTargetEntityId($$JAVA_FIELD_TYPE$$ targetEntityId)
	{
		this.targetEntityId = targetEntityId;
	}
	public $$JAVA_FIELD_TYPE$$ getTargetUserId()
	{
		return this.targetUserId;
	}
	public void setTargetUserId($$JAVA_FIELD_TYPE$$ targetUserId)
	{
		this.targetUserId = targetUserId;
	}
	public $$JAVA_FIELD_TYPE$$ getNotificationMedium()
	{
		return this.notificationMedium;
	}
	public void setNotificationMedium($$JAVA_FIELD_TYPE$$ notificationMedium)
	{
		this.notificationMedium = notificationMedium;
	}
	public $$JAVA_FIELD_TYPE$$ getNotificationLastSentTime()
	{
		return this.notificationLastSentTime;
	}
	public void setNotificationLastSentTime($$JAVA_FIELD_TYPE$$ notificationLastSentTime)
	{
		this.notificationLastSentTime = notificationLastSentTime;
	}
	public $$JAVA_FIELD_TYPE$$ getNextNotificationTime()
	{
		return this.nextNotificationTime;
	}
	public void setNextNotificationTime($$JAVA_FIELD_TYPE$$ nextNotificationTime)
	{
		this.nextNotificationTime = nextNotificationTime;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
