package com.patientapp.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class OrganisationsSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer organisationsId ;
		private $$JAVA_FIELD_TYPE$$ organisationName $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ addressLine1 $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ addressLine2 $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ city $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ residentState $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ pinCode $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ databaseName $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ country $$HASH_SET$$;

	public OrganisationsSearch()
	{
	}
	public java.lang.Integer getOrganisationsSearchId()
	{
		return this.organisationsId;
	}
	public void setOrganisationsSearchId(java.lang.Integer messageQueueId)
	{
		this.organisationsId = organisationsId;
	}
		public $$JAVA_FIELD_TYPE$$ getOrganisationName()
	{
		return this.organisationName;
	}
	public void setOrganisationName($$JAVA_FIELD_TYPE$$ organisationName)
	{
		this.organisationName = organisationName;
	}
	public $$JAVA_FIELD_TYPE$$ getAddressLine1()
	{
		return this.addressLine1;
	}
	public void setAddressLine1($$JAVA_FIELD_TYPE$$ addressLine1)
	{
		this.addressLine1 = addressLine1;
	}
	public $$JAVA_FIELD_TYPE$$ getAddressLine2()
	{
		return this.addressLine2;
	}
	public void setAddressLine2($$JAVA_FIELD_TYPE$$ addressLine2)
	{
		this.addressLine2 = addressLine2;
	}
	public $$JAVA_FIELD_TYPE$$ getCity()
	{
		return this.city;
	}
	public void setCity($$JAVA_FIELD_TYPE$$ city)
	{
		this.city = city;
	}
	public $$JAVA_FIELD_TYPE$$ getResidentState()
	{
		return this.residentState;
	}
	public void setResidentState($$JAVA_FIELD_TYPE$$ residentState)
	{
		this.residentState = residentState;
	}
	public $$JAVA_FIELD_TYPE$$ getPinCode()
	{
		return this.pinCode;
	}
	public void setPinCode($$JAVA_FIELD_TYPE$$ pinCode)
	{
		this.pinCode = pinCode;
	}
	public $$JAVA_FIELD_TYPE$$ getDatabaseName()
	{
		return this.databaseName;
	}
	public void setDatabaseName($$JAVA_FIELD_TYPE$$ databaseName)
	{
		this.databaseName = databaseName;
	}
	public $$JAVA_FIELD_TYPE$$ getCountry()
	{
		return this.country;
	}
	public void setCountry($$JAVA_FIELD_TYPE$$ country)
	{
		this.country = country;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
