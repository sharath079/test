function initializePageOnLoadForOrganisations()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForOrganisations;
