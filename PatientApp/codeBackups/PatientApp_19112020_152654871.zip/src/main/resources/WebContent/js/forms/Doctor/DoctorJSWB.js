function initializePageOnLoadForDoctor()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForDoctor;
