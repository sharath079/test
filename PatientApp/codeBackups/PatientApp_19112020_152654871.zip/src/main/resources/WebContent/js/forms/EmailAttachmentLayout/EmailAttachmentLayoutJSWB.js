function initializePageOnLoadForEmailAttachmentLayout()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForEmailAttachmentLayout;
