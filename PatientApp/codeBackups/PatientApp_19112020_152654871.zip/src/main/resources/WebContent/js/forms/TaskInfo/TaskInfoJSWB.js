function initializePageOnLoadForTaskInfo()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForTaskInfo;
