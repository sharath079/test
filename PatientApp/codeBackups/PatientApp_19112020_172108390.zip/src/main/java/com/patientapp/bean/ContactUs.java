/**
 * 
 */
package com.patientapp.bean;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 * @author admin
 *
 */
@Entity
@Table(name = "ContactUs")
public class ContactUs {
	@Id
	@GeneratedValue
	@Column(name = "contactId")
	private java.lang.Integer contactId;
	@Column(name="fullName")
	private java.lang.String fullName;
	@Column(name = "emailId")
	private java.lang.String emailId;
	@Column(name = "contactNo")
	private java.lang.String contactNo;
	@Column(name = "message")
	private java.lang.String message;
	public java.lang.Integer getContactId() {
		return contactId;
	}
	public void setContactId(java.lang.Integer contactId) {
		this.contactId = contactId;
	}
	public java.lang.String getFullName() {
		return fullName;
	}
	public void setFullName(java.lang.String fullName) {
		this.fullName = fullName;
	}
	public java.lang.String getEmailId() {
		return emailId;
	}
	public void setEmailId(java.lang.String emailId) {
		this.emailId = emailId;
	}
	public java.lang.String getContactNo() {
		return contactNo;
	}
	public void setContactNo(java.lang.String contactNo) {
		this.contactNo = contactNo;
	}
	public java.lang.String getMessage() {
		return message;
	}
	public void setMessage(java.lang.String message) {
		this.message = message;
	}
}
