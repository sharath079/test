function initializePageOnLoadForConfigProperties()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForConfigProperties;
