TRUNCATE Organisations;
TRUNCATE UserInfo;
TRUNCATE PrivilegeGroup;
TRUNCATE PrivilegeGroupItems;
TRUNCATE EmployeeRoles;
TRUNCATE LoginSessionInfo;
TRUNCATE ConfigProperties;
TRUNCATE TaskInfo;
TRUNCATE TaskExecutionInfo;
TRUNCATE TaskLayoutParameters;
TRUNCATE EmailAttachmentLayout;
TRUNCATE TaskScheduleInfo;
TRUNCATE TaskSentInfo;
TRUNCATE Patient;
TRUNCATE Doctor;
TRUNCATE Hospital;

