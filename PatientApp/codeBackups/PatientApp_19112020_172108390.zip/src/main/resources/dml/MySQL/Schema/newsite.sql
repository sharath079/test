drop database patientapp;
create database patientapp;
use patientapp;
source MYSQLDML.sql;
