
function message1()
{
   alert("Custom Alert message--->1")
}

function message2()
{
   alert("Custom Alert message--->2")
}

function message()
{
   alert("Custom Alert message.....")
}
