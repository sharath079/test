

function doAfterPanelRefreshedForTaskLayoutParametersExt()
{
    //Custom handling
}



function doAfterPanelInitializedForTaskLayoutParametersExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForTaskLayoutParametersExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForTaskLayoutParametersExt(fieldName)
{
    //Custom handling
}



function processResultRowForTaskLayoutParametersExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForTaskLayoutParametersExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForTaskLayoutParametersExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForTaskLayoutParametersExt(customEventName)
{
    //Custom handling
}

