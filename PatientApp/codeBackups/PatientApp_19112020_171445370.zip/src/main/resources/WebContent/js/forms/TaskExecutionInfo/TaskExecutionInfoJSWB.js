function initializePageOnLoadForTaskExecutionInfo()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForTaskExecutionInfo;
