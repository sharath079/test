function initializePageOnLoadForPatient()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForPatient;
