

function doAfterPanelRefreshedForPatientExt()
{
    //Custom handling
}



function doAfterPanelInitializedForPatientExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForPatientExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForPatientExt(fieldName)
{
    //Custom handling
}



function processResultRowForPatientExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForPatientExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForPatientExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForPatientExt(customEventName)
{
    //Custom handling
}

