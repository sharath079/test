

function doAfterPanelRefreshedForEmailAttachmentLayoutExt()
{
    //Custom handling
}



function doAfterPanelInitializedForEmailAttachmentLayoutExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForEmailAttachmentLayoutExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForEmailAttachmentLayoutExt(fieldName)
{
    //Custom handling
}



function processResultRowForEmailAttachmentLayoutExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForEmailAttachmentLayoutExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForEmailAttachmentLayoutExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForEmailAttachmentLayoutExt(customEventName)
{
    //Custom handling
}

