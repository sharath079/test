

function doAfterPanelRefreshedForEmployeeRolesExt()
{
    //Custom handling
}



function doAfterPanelInitializedForEmployeeRolesExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForEmployeeRolesExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForEmployeeRolesExt(fieldName)
{
    //Custom handling
}



function processResultRowForEmployeeRolesExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForEmployeeRolesExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForEmployeeRolesExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForEmployeeRolesExt(customEventName)
{
    //Custom handling
}

