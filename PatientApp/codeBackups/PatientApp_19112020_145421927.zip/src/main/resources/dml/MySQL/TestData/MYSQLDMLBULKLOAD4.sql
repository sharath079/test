
 UPDATE Organisations SET organisationName = CONCAT('FIELD_NAME.toUpperCase()', organisations");





 UPDATE Organisations SET addressLine1 = CONCAT('FIELD_NAME.toUpperCase()', organisations");





 UPDATE Organisations SET addressLine2 = CONCAT('FIELD_NAME.toUpperCase()', organisations");





 UPDATE Organisations SET city = CONCAT('FIELD_NAME.toUpperCase()', organisations");





 UPDATE Organisations SET residentState = CONCAT('FIELD_NAME.toUpperCase()', organisations");





 UPDATE Organisations SET pinCode = CONCAT('FIELD_NAME.toUpperCase()', organisations");





 UPDATE Organisations SET databaseName = CONCAT('FIELD_NAME.toUpperCase()', organisations");





 UPDATE Organisations SET country = CONCAT('FIELD_NAME.toUpperCase()', organisations");






 UPDATE UserInfo SET userFirstName = CONCAT('FIELD_NAME.toUpperCase()', userInfo");





 UPDATE UserInfo SET userLastName = CONCAT('FIELD_NAME.toUpperCase()', userInfo");




      








 UPDATE UserInfo SET loginId = CONCAT('FIELD_NAME.toUpperCase()', userInfo");





 UPDATE UserInfo SET loginEmailId = CONCAT('FIELD_NAME.toUpperCase()', userInfo");





 UPDATE UserInfo SET contactNo = CONCAT('FIELD_NAME.toUpperCase()', userInfo");





 UPDATE UserInfo SET loginPassword = CONCAT('FIELD_NAME.toUpperCase()', userInfo");





 UPDATE UserInfo SET resetToken = CONCAT('FIELD_NAME.toUpperCase()', userInfo");






 UPDATE PrivilegeGroup SET privilegeGroupName = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroup");





 UPDATE PrivilegeGroup SET privilegeCode = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroup");





 UPDATE PrivilegeGroup SET applicableUserType = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroup");





 UPDATE PrivilegeGroup SET selfServiceUser = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroup");





 UPDATE PrivilegeGroup SET privilegeGroupDescription = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroup");






 UPDATE PrivilegeGroupItems SET privilegeActionType = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroupItems");





 UPDATE PrivilegeGroupItems SET privilegeObjectType = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroupItems");





 UPDATE PrivilegeGroupItems SET privilegeObjectName = CONCAT('FIELD_NAME.toUpperCase()', privilegeGroupItems");






 UPDATE EmployeeRoles SET description = CONCAT('FIELD_NAME.toUpperCase()', employeeRoles");






 UPDATE LoginSessionInfo SET loginUserType = CONCAT('FIELD_NAME.toUpperCase()', loginSessionInfo");





 UPDATE LoginSessionInfo SET selfServiceUserType = CONCAT('FIELD_NAME.toUpperCase()', loginSessionInfo");





 UPDATE LoginSessionInfo SET sessionId = CONCAT('FIELD_NAME.toUpperCase()', loginSessionInfo");





 UPDATE LoginSessionInfo SET userId = loginSessionInfo;

      


 UPDATE ConfigProperties SET propertyName = CONCAT('FIELD_NAME.toUpperCase()', configProperties");





 UPDATE ConfigProperties SET propertyValue = CONCAT('FIELD_NAME.toUpperCase()', configProperties");






 UPDATE TaskInfo SET taskName = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET taskDescription = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET taskType = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET apiName = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET targetEntityQuery = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET targetUserIdColumnAlias = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET targetEntityIdColumnAlias = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET enableInAppNotification = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET inAppNotificationLayout = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET enableEmailNotification = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET emailColumnAlias = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET emailNotificationLayout = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET emailSubject = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET enableSmsNotification = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET smsColumnAlias = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET smsNotificationLayout = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET sMSText = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET isActive = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");




      








 UPDATE TaskInfo SET taskFrequency = taskInfo;


 UPDATE TaskInfo SET taskFrequencyUnit = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET isRecurring = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET firstRunType = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET dateColumnAlias = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET firstRunDateCalculationMethod = CONCAT('FIELD_NAME.toUpperCase()', taskInfo");





 UPDATE TaskInfo SET firstRunDateGapInYears = taskInfo;


 UPDATE TaskInfo SET firstRunDateGapInMonths = taskInfo;


 UPDATE TaskInfo SET firstRunDateGapInDays = taskInfo;


 UPDATE TaskInfo SET firstRunDateGapInHours = taskInfo;


 UPDATE TaskInfo SET firstRunDateGapInMinutes = taskInfo;


 UPDATE TaskInfo SET firstRunDateGapInSeconds = taskInfo;



 UPDATE TaskExecutionInfo SET taskTimeCalculationType = CONCAT('FIELD_NAME.toUpperCase()', taskExecutionInfo");





 UPDATE TaskExecutionInfo SET firstRunDateCalculationMethod = CONCAT('FIELD_NAME.toUpperCase()', taskExecutionInfo");





 UPDATE TaskExecutionInfo SET firstRunDateGapInYears = taskExecutionInfo;


 UPDATE TaskExecutionInfo SET firstRunDateGapInMonths = taskExecutionInfo;


 UPDATE TaskExecutionInfo SET firstRunDateGapInDays = taskExecutionInfo;


 UPDATE TaskExecutionInfo SET firstRunDateGapInHours = taskExecutionInfo;


 UPDATE TaskExecutionInfo SET firstRunDateGapInMinutes = taskExecutionInfo;


 UPDATE TaskExecutionInfo SET firstRunDateGapInSeconds = taskExecutionInfo;



 UPDATE TaskLayoutParameters SET parameterName = CONCAT('FIELD_NAME.toUpperCase()', taskLayoutParameters");





 UPDATE TaskLayoutParameters SET parameterValueType = CONCAT('FIELD_NAME.toUpperCase()', taskLayoutParameters");





 UPDATE TaskLayoutParameters SET parameterValue = CONCAT('FIELD_NAME.toUpperCase()', taskLayoutParameters");






 UPDATE EmailAttachmentLayout SET emailAttachmentLayoutName = CONCAT('FIELD_NAME.toUpperCase()', emailAttachmentLayout");





 UPDATE EmailAttachmentLayout SET comments = CONCAT('FIELD_NAME.toUpperCase()', emailAttachmentLayout");






 UPDATE TaskScheduleInfo SET targetEntityId = taskScheduleInfo;


 UPDATE TaskScheduleInfo SET targetUserId = taskScheduleInfo;


 UPDATE TaskScheduleInfo SET notificationMedium = CONCAT('FIELD_NAME.toUpperCase()', taskScheduleInfo");




     
 UPDATE TaskSentInfo SET targetEntityId = taskSentInfo;


 UPDATE TaskSentInfo SET targetUserId = taskSentInfo;


 UPDATE TaskSentInfo SET notificationMedium = CONCAT('FIELD_NAME.toUpperCase()', taskSentInfo");





 UPDATE TaskSentInfo SET layoutInfoText = CONCAT('FIELD_NAME.toUpperCase()', taskSentInfo");




     
 UPDATE Patient SET patientName = CONCAT('FIELD_NAME.toUpperCase()', patient");





 UPDATE Patient SET patientGender = CONCAT('FIELD_NAME.toUpperCase()', patient");





 UPDATE Patient SET selectDoctor = CONCAT('FIELD_NAME.toUpperCase()', patient");






 UPDATE Doctor SET doctorName = CONCAT('FIELD_NAME.toUpperCase()', doctor");





 UPDATE Doctor SET hospitalName = CONCAT('FIELD_NAME.toUpperCase()', doctor");






 UPDATE Hospital SET hospName = CONCAT('FIELD_NAME.toUpperCase()', hospital");





 UPDATE Hospital SET hospAddress = $$TEST_DATA$$;





