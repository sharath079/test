function initializePageOnLoadForPrivilegeGroupItems()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForPrivilegeGroupItems;
