package com.patientapp.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class PrivilegeGroupSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer privilegeGroupId ;
		private $$JAVA_FIELD_TYPE$$ privilegeGroupName $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ privilegeCode $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ applicableUserType $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ selfServiceUser $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ privilegeGroupDescription $$HASH_SET$$;

	public PrivilegeGroupSearch()
	{
	}
	public java.lang.Integer getPrivilegeGroupSearchId()
	{
		return this.privilegeGroupId;
	}
	public void setPrivilegeGroupSearchId(java.lang.Integer messageQueueId)
	{
		this.privilegeGroupId = privilegeGroupId;
	}
		public $$JAVA_FIELD_TYPE$$ getPrivilegeGroupName()
	{
		return this.privilegeGroupName;
	}
	public void setPrivilegeGroupName($$JAVA_FIELD_TYPE$$ privilegeGroupName)
	{
		this.privilegeGroupName = privilegeGroupName;
	}
	public $$JAVA_FIELD_TYPE$$ getPrivilegeCode()
	{
		return this.privilegeCode;
	}
	public void setPrivilegeCode($$JAVA_FIELD_TYPE$$ privilegeCode)
	{
		this.privilegeCode = privilegeCode;
	}
	public $$JAVA_FIELD_TYPE$$ getApplicableUserType()
	{
		return this.applicableUserType;
	}
	public void setApplicableUserType($$JAVA_FIELD_TYPE$$ applicableUserType)
	{
		this.applicableUserType = applicableUserType;
	}
	public $$JAVA_FIELD_TYPE$$ getSelfServiceUser()
	{
		return this.selfServiceUser;
	}
	public void setSelfServiceUser($$JAVA_FIELD_TYPE$$ selfServiceUser)
	{
		this.selfServiceUser = selfServiceUser;
	}
	public $$JAVA_FIELD_TYPE$$ getPrivilegeGroupDescription()
	{
		return this.privilegeGroupDescription;
	}
	public void setPrivilegeGroupDescription($$JAVA_FIELD_TYPE$$ privilegeGroupDescription)
	{
		this.privilegeGroupDescription = privilegeGroupDescription;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
