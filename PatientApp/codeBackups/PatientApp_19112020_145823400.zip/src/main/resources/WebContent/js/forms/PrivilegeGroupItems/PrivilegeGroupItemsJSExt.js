

function doAfterPanelRefreshedForPrivilegeGroupItemsExt()
{
    //Custom handling
}



function doAfterPanelInitializedForPrivilegeGroupItemsExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForPrivilegeGroupItemsExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForPrivilegeGroupItemsExt(fieldName)
{
    //Custom handling
}



function processResultRowForPrivilegeGroupItemsExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForPrivilegeGroupItemsExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForPrivilegeGroupItemsExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForPrivilegeGroupItemsExt(customEventName)
{
    //Custom handling
}

