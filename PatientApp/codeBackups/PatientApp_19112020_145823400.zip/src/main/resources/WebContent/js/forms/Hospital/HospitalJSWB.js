function initializePageOnLoadForHospital()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForHospital;
