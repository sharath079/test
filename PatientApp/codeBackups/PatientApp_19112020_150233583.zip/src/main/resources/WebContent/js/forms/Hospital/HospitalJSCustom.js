function message()
{
	alert("This is customised alert message Refresh");
}