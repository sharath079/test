function initializePageOnLoadForTaskScheduleInfo()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForTaskScheduleInfo;
