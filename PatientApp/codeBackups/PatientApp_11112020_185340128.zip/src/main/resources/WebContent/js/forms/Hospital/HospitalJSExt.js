

function doAfterPanelRefreshedForHospitalExt()
{
    //Custom handling
}



function doAfterPanelInitializedForHospitalExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForHospitalExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForHospitalExt(fieldName)
{
    //Custom handling
}



function processResultRowForHospitalExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForHospitalExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForHospitalExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForHospitalExt(customEventName)
{
    //Custom handling
}

