

function doAfterPanelRefreshedForTaskInfoExt()
{
    //Custom handling
}



function doAfterPanelInitializedForTaskInfoExt()
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised for select option fields
 */


function doAfterSelectOptionChangedForTaskInfoExt(fieldName)
{
    //Custom handling
}

/*
 * This function is called after completion of the 
 * ajax request raised after selecting lookup row for 
 * any of the fields
 */


function doAfterLookupRowChangedForTaskInfoExt(fieldName)
{
    //Custom handling
}



function processResultRowForTaskInfoExt(rowObj)
{
    //Custom handling
}



function doAfterLookupOptionLoadedForTaskInfoExt(lookupOptionElement, paramsMap)
{
    //Custom handling
}



function doBeforeExecuteCustomAPIForTaskInfoExt(customEventName)
{
    //Custom handling
}



function doAfterExecuteCustomAPIForTaskInfoExt(customEventName)
{
    //Custom handling
}

