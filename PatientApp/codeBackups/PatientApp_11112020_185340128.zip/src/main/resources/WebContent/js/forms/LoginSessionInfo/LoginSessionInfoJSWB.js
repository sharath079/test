function initializePageOnLoadForLoginSessionInfo()
{
	initializeMenu();
}
window.onload = initializePageOnLoadForLoginSessionInfo;
