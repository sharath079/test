package com.patientapp.util;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import org.apache.log4j.Logger;
import com.google.gson.JsonObject;
import com.patientapp.util.CommonUtil;
public class BusinessAPIs
{
}
