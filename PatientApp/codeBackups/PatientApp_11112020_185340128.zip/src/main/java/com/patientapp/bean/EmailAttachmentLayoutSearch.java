package com.patientapp.bean;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import com.vw.runtime.RulesBean;
@SuppressWarnings("unused")
/**
 * @author  Srikanth Brahmadevara: Harivara Technology Solutions, CODE GENERATED
 */
public class EmailAttachmentLayoutSearch extends RulesBean implements java.io.Serializable
{
	/*private static final long serialVersionUID = 1L;
	private java.lang.Integer emailAttachmentLayoutId ;
		private $$JAVA_FIELD_TYPE$$ emailAttachmentLayoutName $$HASH_SET$$;
	private $$JAVA_FIELD_TYPE$$ comments $$HASH_SET$$;

	public EmailAttachmentLayoutSearch()
	{
	}
	public java.lang.Integer getEmailAttachmentLayoutSearchId()
	{
		return this.emailAttachmentLayoutId;
	}
	public void setEmailAttachmentLayoutSearchId(java.lang.Integer messageQueueId)
	{
		this.emailAttachmentLayoutId = emailAttachmentLayoutId;
	}
		public $$JAVA_FIELD_TYPE$$ getEmailAttachmentLayoutName()
	{
		return this.emailAttachmentLayoutName;
	}
	public void setEmailAttachmentLayoutName($$JAVA_FIELD_TYPE$$ emailAttachmentLayoutName)
	{
		this.emailAttachmentLayoutName = emailAttachmentLayoutName;
	}
	public $$JAVA_FIELD_TYPE$$ getComments()
	{
		return this.comments;
	}
	public void setComments($$JAVA_FIELD_TYPE$$ comments)
	{
		this.comments = comments;
	}

	private Date vwLastModifiedDate;
	private java.lang.Integer vwLastModifiedTime;
	private java.lang.String vwLastAction;
	private java.lang.String vwModifiedBy;
	private java.lang.String vwTxnRemarks;
	private java.lang.String vwTxnStatus;
	private java.lang.Integer isRequestUnderProcesss;
	private java.lang.Integer legacyRecordId;
	public Date getVwLastModifiedDate()
	{
		return this.vwLastModifiedDate;
	}
	public void setVwLastModifiedDate(Date vwLastModifiedDate)
	{
		this.vwLastModifiedDate = vwLastModifiedDate;
	}
	public Integer getVwLastModifiedTime()
	{
		return this.vwLastModifiedTime;
	}
	public void setVwLastModifiedTime(Integer vwLastModifiedTime)
	{
		this.vwLastModifiedTime = vwLastModifiedTime;
	}
	public String getVwLastAction()
	{
		return this.vwLastAction;
	}
	public void setVwLastAction(String vwLastAction)
	{
		this.vwLastAction = vwLastAction;
	}
	public String getVwModifiedBy()
	{
		return this.vwModifiedBy;
	}
	public void setVwModifiedBy(String vwModifiedBy)
	{
		this.vwModifiedBy = vwModifiedBy;
	}
	public String getVwTxnRemarks()
	{
		return this.vwTxnRemarks;
	}
	public void setVwTxnRemarks(String vwTxnRemarks)
	{
		this.vwTxnRemarks = vwTxnRemarks;
	}
	public String getVwTxnStatus()
	{
		return this.vwTxnStatus;
	}
	public void setVwTxnStatus(String vwTxnStatus)
	{
		this.vwTxnStatus = vwTxnStatus;
	}
	public Integer getIsRequestUnderProcesss()
	{
		return this.isRequestUnderProcesss;
	}
	public void setIsRequestUnderProcesss(Integer isRequestUnderProcesss)
	{
		this.isRequestUnderProcesss = isRequestUnderProcesss;
	}
	public Integer getLegacyRecordId()
	{
		return this.legacyRecordId;
	}
	public void setLegacyRecordId(Integer legacyRecordId)
	{
		this.legacyRecordId = legacyRecordId;
	}*/
}
